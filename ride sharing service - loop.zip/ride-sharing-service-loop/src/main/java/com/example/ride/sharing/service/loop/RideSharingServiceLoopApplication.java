package com.example.ride.sharing.service.loop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RideSharingServiceLoopApplication {

	public static void main(String[] args) {
		SpringApplication.run(RideSharingServiceLoopApplication.class, args);
	}

}
